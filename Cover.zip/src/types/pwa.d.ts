interface Navigator {
  standalone?: boolean;
}
